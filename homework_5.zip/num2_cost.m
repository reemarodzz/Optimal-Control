  function y = num2_cost(p) 
 y = p(end);
end

