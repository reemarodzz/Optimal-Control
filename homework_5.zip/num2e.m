clc;
clear all;
close all;

Optimal_Time= [ 1.0000 1.0200 1.0989 1.1007];
constraint=[10 7 5 3];
figure; 
plot(constraint,Optimal_Time);
grid;
 