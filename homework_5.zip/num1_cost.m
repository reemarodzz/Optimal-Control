function y = num1_cost(p) 
 y = p(end);
end

